<!-- Main menu (tabs) -->
     <div id="tabs" class="noprint">

            <h3 class="noscreen">Navigation</h3>
            <ul class="box">
                <li><a href="index.php">Home<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Profile.php">Profile<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Education.php">Education<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="SearchJob.php">Search Job<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="SearchInstitute.php">Search Course<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Walkin.php">Walkin Interview<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Feedback.php">Feedback<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="listofjobs.php">List of jobs<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="viewappliedjobs.php">List of applied jobs<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="listoftrainings.php">List of trainings<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="viewappliedtrainings.php">List of applied trainings<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="session_destroy.php">Logout<span class="tab-l"></span><span class="tab-r"></span></a></li>
            </ul>

        <hr class="noscreen" />
     </div> <!-- /tabs -->